//
//  WebServices.swift
//  Avadh_Project
//
//  Created by Avadh Mevada on 06/04/21.
//

import Foundation
import Alamofire
import UIKit
enum WebServiceNames: String {
    case baseUrl = "https://itunes.apple.com/search?term="
    
    func baseUrl() -> String {
        return "https://itunes.apple.com/search?term="
    }
}

class WebServices: NSObject {
    
    class func getNews(text: String, completion : @escaping (_ response : [NewsResponseModel], _ status: String?)-> ()) {
        let url = WebServiceNames.baseUrl.baseUrl() + "\(text)" + "&entity=song" //+ WebServiceNames.news.rawValue
        let params = ["Songs": ""] as [String: AnyObject]
        WebServices.getWebService(urlString: url, params: params) { (response, status) in
            if let data = response?.results as? [[String: Any]] {
                completion(NewsResponseModel.parse(arrDict: data), "ok")
            }else {
                completion([], "")
            }
        }
    }
    
    class func getWebService(urlString: String, isDiscover:Bool = false, params: [String : AnyObject], completion : @escaping (_ response : Response?, _ status: String?)-> Void) {

//        let headers:HTTPHeaders = WebServices.setHeaders()
        alamofireFunction(urlString: urlString, method: .get, paramters: params) { (response, message, success) in
//            SVProgressHUD.dismiss()
            if response != nil {
                let resp:Response = Response()
                resp.parseData(response as AnyObject)
                completion(resp, resp.status)
            }else{
                completion(nil, "")
            }
        }
    }
    
    class func alamofireFunction(urlString : String, method : Alamofire.HTTPMethod, paramters : [String : Any], completion : @escaping (_ response : AnyObject?, _ message: String?, _ success : Bool)-> Void){
        if method == Alamofire.HTTPMethod.post {
            Alamofire.request(urlString, method: .post, parameters: paramters, encoding: URLEncoding.default).responseJSON { response in
                
                print(urlString)
                do {
                    let request = try JSONSerialization.data(withJSONObject: paramters, options: .prettyPrinted)
                    let jsonString = String(data: request, encoding: String.Encoding.utf8) as String?
                    print("JSON REQUEST: \(jsonString ?? "")")

                } catch let error {
                    print(error.localizedDescription)
                }
                switch response.result {
                case .success(let value as AnyObject):
                    completion(value, "", true)
                case .failure(let error):
                    completion(nil, error.localizedDescription, false)
                default:
                    completion(nil, "", false)
                }
            }
            
        }
        else if method == Alamofire.HTTPMethod.get {
            Alamofire.request(urlString, method: .get, parameters: paramters, encoding: URLEncoding.default).responseJSON { response in
                print(urlString)
                do {
                    let request = try JSONSerialization.data(withJSONObject: paramters, options: .prettyPrinted)
                    let jsonString = String(data: request, encoding: String.Encoding.utf8) as String?
                    print("JSON REQUEST: \(jsonString ?? "")")
                    
                } catch let error {
                    print(error.localizedDescription)
                }
                
                switch response.result {
                case .success(let value as AnyObject):
                    completion(value, "", true)
                case .failure(let error):
                    completion(nil, error.localizedDescription, false)
                default:
                    completion(nil, "", false)
                }
            }
        }
        else {
            Alamofire.request(urlString).responseJSON { (response) in
                
                switch response.result {
                case .success(let value as AnyObject):
                    completion(value, "", true)
                case .failure(let error):
                    completion(nil, error.localizedDescription, false)
                default:
                    completion(nil, "", false)
                }
            }
        }
    }
    
    class func alertMessage(alerttitle:String,_ message : String, controller : UIViewController){
        let alertViewController = UIAlertController(title:alerttitle,  message:message, preferredStyle: .alert)
        alertViewController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        controller.present(alertViewController, animated: true, completion: nil)
    }
  
}
extension String {
    
    func trimSpace() -> String{
        return self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tapGesture = UITapGestureRecognizer(target: self,
                         action: #selector(hideKeyboard))
        view.addGestureRecognizer(tapGesture)
    }

    @objc func hideKeyboard() {
        view.endEditing(true)
    }
}
