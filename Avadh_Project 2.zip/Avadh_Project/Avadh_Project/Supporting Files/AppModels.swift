//
//  AppModels.swift
//  Avadh_Project
//
//  Created by Avadh Mevada on 06/04/21.
//

import Foundation

class NewsResponseModel{

    public var artistName = ""
    public var collectionName = ""
    public var trackName = ""
    public var title = ""
    public var artworkUrl100 = ""
    init() {
    }
    
    init(artistName: String?, collectionName: String?, trackName: String?, title: String?, artworkUrl100: String?) {

        self.artistName = artistName ?? ""
        self.collectionName = collectionName ?? ""
        self.trackName = trackName ?? ""
        self.title = title ?? ""
        self.artworkUrl100 = artworkUrl100 ?? ""
        
    }
    
    class func parse(arrDict: [[String:Any]]) -> [NewsResponseModel] {
        var arrNews:[NewsResponseModel] = []
        
        for dict in arrDict {
            arrNews.append(NewsResponseModel.parse(dict: dict))
        }
        return arrNews
    }
    
    class func parse(dict: [String:Any]) -> NewsResponseModel {
        let objNewsResponse = NewsResponseModel.init()
        objNewsResponse.artistName = dict["artistName"] as? String ?? ""
        objNewsResponse.collectionName = dict["collectionName"] as? String ?? ""
        objNewsResponse.trackName = dict["trackName"] as? String ?? ""
        objNewsResponse.title = dict["title"] as? String ?? ""
        objNewsResponse.artworkUrl100 = dict["artworkUrl100"] as? String ?? ""
        return objNewsResponse
    }
}


class Response : NSObject {
    var results: Any?
    var status: String?

    func parseData(_ response:AnyObject){
        results = response.value(forKey: "results")
        status = response.value(forKey: "status") as? String ?? ""
    }
}
