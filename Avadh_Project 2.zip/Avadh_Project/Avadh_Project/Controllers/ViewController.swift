//
//  ViewController.swift
//  Avadh_Project
//
//  Created by Avadh Mevada on 06/04/21.
//

import UIKit
import SystemConfiguration
import SDWebImage

class ViewController: UIViewController {
    @IBOutlet weak var tblNewsList: UITableView!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var btnSearch: UIButton!
    
    var arrNews:[NewsResponseModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        hideKeyboardWhenTappedAround()
        tblNewsList.isHidden = true
        if isConnectedToNetwork() {
            getNewsList(text: "bollywood")
        }else {
            
            WebServices.alertMessage(alerttitle: "Songs Channel", "Connection Lost, Please Connect to Network!", controller: self)
        }
    }
    
    func getNewsList(text: String) {
        WebServices.getNews(text: text) { (arrNews, status) in
            if status == "ok" {
                self.arrNews = arrNews
                self.tblNewsList.isHidden = false
                self.tblNewsList.reloadData()
                self.tblNewsList.scrollsToTop = true
            }else {
                WebServices.alertMessage(alerttitle: "Songs Channel", "Songs Not Found", controller: self)
            }
        }
    }
    
    func isConnectedToNetwork() -> Bool {
       var zeroAddress = sockaddr_in()
       zeroAddress.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
       zeroAddress.sin_family = sa_family_t(AF_INET)

       guard let defaultRouteReachability = withUnsafePointer(to: &zeroAddress, {
           $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
               SCNetworkReachabilityCreateWithAddress(nil, $0)
           }
       }) else {
           return false
       }

       var flags: SCNetworkReachabilityFlags = []
       if !SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags) {
           return false
       }

       let isReachable = flags.contains(.reachable)
       let needsConnection = flags.contains(.connectionRequired)

       return (isReachable && !needsConnection)
    }
    @IBAction func onTapReset(_ sender: Any) {
        getNewsList(text: "bollywood")
        txtSearch.text = nil
        tblNewsList.scrollsToTop = true
    }
    @IBAction func onTapSearch(_ sender: Any) {
        if txtSearch.text != "" {
            let searchText = txtSearch.text?.trimSpace() ?? "" as String
            getNewsList(text: searchText)
        }else{
            WebServices.alertMessage(alerttitle: "Songs Channel", "Please Enter Value to search!", controller: self)
        }
    }
}

extension ViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrNews.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblNewsList.dequeueReusableCell(withIdentifier: "newsCell") as! newsCell
        let newsObj = arrNews[indexPath.row]
//        cell.btnReadMore.isHidden = true

        cell.selectionStyle = .none
        cell.bgView.layer.cornerRadius = 8
        cell.bgView.layer.masksToBounds = true
        cell.imgItem.layer.cornerRadius = 6
        cell.imgItem.layer.masksToBounds = true
        cell.imgItem.layer.borderWidth = 0.8
        cell.imgItem.layer.borderColor = UIColor.cyan.cgColor
                
        if newsObj.artworkUrl100 != "" {
            let url = URL(string: newsObj.artworkUrl100)
            cell.imgItem.sd_setImage(with: url, completed: nil)
            cell.imgItem.sd_imageIndicator = SDWebImageActivityIndicator.gray
        }else{
            cell.imgItem.image = UIImage(named: "image")
        }
        cell.setupCellData(trackName: newsObj.trackName, ArtistName: newsObj.artistName, collectionName: newsObj.collectionName)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
              return 200
          }
    
}

class newsCell : UITableViewCell {
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var imgItem: UIImageView!
    @IBOutlet weak var lbltrackName: UILabel!
    @IBOutlet weak var lblArtistName: UILabel!
    @IBOutlet weak var lblcollectionName: UILabel!
    func setupCellData(trackName: String, ArtistName: String, collectionName: String ){
        self.lbltrackName.text = trackName
        self.lblArtistName.text = ArtistName
        self.lblcollectionName.text = collectionName
    }
}

extension UILabel {

        func addTrailing(with trailingText: String, moreText: String, moreTextFont: UIFont, moreTextColor: UIColor) {
            let readMoreText: String = trailingText + moreText

            let lengthForVisibleString: Int = self.vissibleTextLength
            let mutableString: String = self.text!
            let trimmedString: String? = (mutableString as NSString).replacingCharacters(in: NSRange(location: lengthForVisibleString, length: ((self.text?.count)! - lengthForVisibleString)), with: "")
            let readMoreLength: Int = (readMoreText.count)
            let trimmedForReadMore: String = (trimmedString! as NSString).replacingCharacters(in: NSRange(location: ((trimmedString?.count ?? 0) - readMoreLength), length: readMoreLength), with: "") + trailingText
            let answerAttributed = NSMutableAttributedString(string: trimmedForReadMore, attributes: [NSAttributedString.Key.font: self.font])
            let readMoreAttributed = NSMutableAttributedString(string: moreText, attributes: [NSAttributedString.Key.font: moreTextFont, NSAttributedString.Key.foregroundColor: moreTextColor])
            answerAttributed.append(readMoreAttributed)
            self.attributedText = answerAttributed
        }

        var vissibleTextLength: Int {
            let font: UIFont = self.font
            let mode: NSLineBreakMode = self.lineBreakMode
            let labelWidth: CGFloat = self.frame.size.width
            let labelHeight: CGFloat = self.frame.size.height
            let sizeConstraint = CGSize(width: labelWidth, height: CGFloat.greatestFiniteMagnitude)

            let attributes: [AnyHashable: Any] = [NSAttributedString.Key.font: font]
            let attributedText = NSAttributedString(string: self.text!, attributes: attributes as? [NSAttributedString.Key : Any])
            let boundingRect: CGRect = attributedText.boundingRect(with: sizeConstraint, options: .usesLineFragmentOrigin, context: nil)

            if boundingRect.size.height > labelHeight {
                var index: Int = 0
                var prev: Int = 0
                let characterSet = CharacterSet.whitespacesAndNewlines
                repeat {
                    prev = index
                    if mode == NSLineBreakMode.byCharWrapping {
                        index += 1
                    } else {
                        index = (self.text! as NSString).rangeOfCharacter(from: characterSet, options: [], range: NSRange(location: index + 1, length: self.text!.count - index - 1)).location
                    }
                } while index != NSNotFound && index < self.text!.count && (self.text! as NSString).substring(to: index).boundingRect(with: sizeConstraint, options: .usesLineFragmentOrigin, attributes: attributes as? [NSAttributedString.Key : Any], context: nil).size.height <= labelHeight
                return prev
            }
            return self.text!.count
        }
    }
